/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question_1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Mutsh
 */
public class Question_1 {
 

    public static void main(String[] args) {

        // One-dimensional array containing city names
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};

        // Two-dimensional array:
        // Column 0 = Car accidents
        // Column 1 = Motorbike accidents
        int[][] accidents = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };
        int[] cityTotals = new int[cities.length];
        int[] consoleTotals = new int[total.length];

        System.out.println("GAMING CONSOLE REPORT");
        System.out.println("--------------------------------------------------------");
        System.out.printf("%-20s %-10s %-15s %-10s%n",
                "City", "PS5", "XBOX", "SWITCH");
        System.out.println("--------------------------------------------------------");

        int highestTotal = 0;
        String highestCity = "";

        for (int i = 0; i < cities.length; i++) {
            int total = accidents[i][0] + accidents[i][1];

            System.out.printf("%-20s %-10d %-15d %-10d%n",
                    cities[i], accidents[i][0], accidents[i][1], total);
for (int row = 0; row < cities.length; row++) {
            for (int col = 0; col < cities[row].length(); col++) {
                Total[row] += cities[col][row];
                citiesTotals[row] += cities[col][row];
            }
        }
            if (total > highestTotal) {
                highestTotal = total;
                highestCity = cities[i];
            }
        }

        System.out.println("--------------------------------------------------------");
        System.out.println("City with the greatest number: " + highestTotal);
        System.out.println("City with the most sales: " + highestCity);
        System.out.println("--------------------------------------------------------");
    }
}


