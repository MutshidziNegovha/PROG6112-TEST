/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.q2;

public abstract class Consoles {

    private String name;
    private double sale;
    private double total;

    public Consoles(String name, double sales) {
        this.name = name;
        this.sale = sale;
        calculateFine();
    }

    // Calculate the fine according to the question
    protected void calculateFine() {
        if (sale >= 120) {
            total = sale * 10.20;
        } else {
            total = 0.0;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSale() {
        return sale;
    }

    public void setSale(double sale) {
        this.sale = sale;
        calculateSales();
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
