/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question_2;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author Mutsh
 */
public class ConsoleReportApllication {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
           
            System.out.println("Select the beverage type");
            
            System.out.println("1. PS5");
            System.out.println("2. XBOX");
            System.out.println("3. SWITCH");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    enterNewFine(scanner);
                    break;

                case "2":
                    viewAllFines();
                    break;

                case "3":
                    running = false;
                    System.out.println("Thank you. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please select 1, 2 or 3.");
            }
        }

        scanner.close();
    }

    private static void enterNewFine(Scanner scanner) {
        try {
            System.out.print("Enter citizen name: ");
            String name = scanner.nextLine().trim();

            if (name.isEmpty()) {
                System.out.println("Name cannot be empty.");
                return;
            }

            System.out.print("Enter speed in km/h: ");
            double speed = Double.parseDouble(scanner.nextLine());

            if (speed < 0) {
                System.out.println("Speed cannot be negative.");
                return;
            }

            SpeedingFines speedingFine = new SpeedingFines(name, speed);

            speedingFine.PrintFine();
            speedingFine.saveToFile();

            System.out.println("Record saved successfully to fines.txt.");

        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Please enter a valid speed.");
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }

    private static void viewAllFines() {
        try {
            File file = new File("fines.txt");

            if (!file.exists()) {
                System.out.println("\nNo fines.txt file exists yet. Enter a fine first.");
                return;
            }

            // An object is created only to use the required readFromFile() method.
            SpeedingFines reader = new SpeedingFines("System", 0);
            reader.readFromFile();

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }
}
